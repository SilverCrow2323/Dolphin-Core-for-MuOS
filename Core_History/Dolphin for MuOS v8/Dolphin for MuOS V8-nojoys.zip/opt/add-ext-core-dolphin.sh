#!/bin/bash

# Simply copy this script to another filename and run it to add that core to launch.sh

script_file=${0##*/}

# Use core from argument; if non provided, use core from filename
core=$1
if [ ${core} == "" ]; then
	core=$(echo ${script_file%.*} |sed 's/add-ext-core-//')
fi

# Use script from argument; if non-provided, use default
script=$2
if [ ${script} == "" ]; then
	script="/opt/muos/script/launch/ext-${core}.sh"
fi

launch_path=/opt/muos/script/mux/launch.sh
launch_path_new="${launch_path}.new"
check_result=$(cat "${launch_path}" |grep "ext-${core}")

if [ "${check_result}" == "" ]; then
	rm ${launch_path_new} 2> /dev/null

	IFS=$'\n'
	for line in $(cat ${launch_path}); do
		if [ ${line} == "# External Script" ]; then
			look_for_insert_point=true
		elif [[ ${look_for_insert_point} == "true" ]]; then
			if [[ ${line} == elif* ]] || [[ ${line} == \#* ]]; then
				# Found it
				look_for_insert_point=false
				echo "# ${core^} External" >> ${launch_path_new}
				echo "elif [ \"\$CORE\" = ext-${core} ]; then" >> ${launch_path_new}
				echo "	${script} \"\$NAME\" \"\$CORE\" \"\$ROM\"" >> ${launch_path_new}
			fi
		fi
		echo ${line} >> ${launch_path_new}
	done

	mv ${launch_path_new} ${launch_path}
	chmod +x ${launch_path}
fi

