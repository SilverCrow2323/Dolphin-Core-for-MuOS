#!/bin/bash

NAME=$1
CORE=$2
ROM=$3

export EMUDIR="/mnt/mmc/MUOS/emulator/dolphin"
export SDL_GAMECONTROLLERCONFIG_FILE="/usr/lib32/gamecontrollerdb.txt"
export SDL_HQ_SCALER="$(GET_VAR "device" "sdl/scaler")"
export SDL_ROTATION="$(GET_VAR "device" "sdl/rotation")"
export SDL_BLITTER_DISABLED="$(GET_VAR "device" "sdl/blitter_disabled")"

pkill -f "playbgm.sh" && pkill -f "muplay"
echo app > /tmp/act_go

. /opt/muos/script/var/func.sh

for i in 1 2; do
    cat /dev/zero > /dev/fb0 2>/dev/null
done

cd "$EMUDIR" || exit

cd Config

# GFX.ini
case ${CORE} in
	*defaultgfx*)
		cp GFX.ini\(Remove\ This\ Text\ For\ Default\) GFX.ini
		;;
	*speedhack*)
		cp GFX.ini\(Remove\ This\ Text\ For\ Alternate\ Speedhacks\) GFX.ini
		;;
	*blackscreenfix*)
		cp GFX.ini\(Remove\ This\ Text\ For\ Games\ That\ Have\ Black\ Screen\) GFX.ini
		;;
esac

# GCPadNew.ini
case ${CORE} in
	*hasjoys*)
		cp GCPadNew.ini\(Remove\ This\ Text\ For\ Systems\ With\ Joysticks\) GCPadNew.ini
		;;
	*nojoys*)
		cp GCPadNew.ini\(Remove\ This\ Text\ For\ Systems\ With\ No\ Joystick\) GCPadNew.ini
		;;
esac

# WiimoteNew.ini
case ${CORE} in
	*hasjoys-upright*)
		cp WiimoteNew.ini\(Remove\ This\ Text\ For\ Systems\ With\ Joysticks\) WiimoteNew.ini
		;;
	*hasjoys-sideways*)
		cp WiimoteNew.ini\(\(Sideways\)Remove\ This\ Text\ For\ Systems\ With\ Joysticks\) WiimoteNew.ini
		;;
	*nojoys-upright*)
		cp WiimoteNew.ini\(Remove\ This\ Text\ For\ Systems\ With\ No\ Joysticks\) WiimoteNew.ini
		;;
	*nojoys-sideways*)
		cp WiimoteNew.ini\(\(Sideways\)Remove\ This\ Text\ For\ Systems\ With\ No\ Joysticks\) WiimoteNew.ini
		;;
esac

cd ..
"./dolphin" -e "$ROM" -u "$EMUDIR"

unset SDL_HQ_SCALER
unset SDL_ROTATION
unset SDL_BLITTER_DISABLED
