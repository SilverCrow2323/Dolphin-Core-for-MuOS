#!/bin/bash

# Simply copy this script to another filename and run it to remove that core from launch.sh

script_file=${0##*/}

# Use core from argument; if non provided, use core from filename
core=$1
if [ ${core} == "" ]; then
	core=$(echo ${script_file%.*} |sed 's/remove-ext-core-//')
fi

launch_path=/opt/muos/script/mux/launch.sh
launch_path_new="${launch_path}.new"
check_result=$(cat "${launch_path}" |grep "ext-${core}")

if [ "${check_result}" != "" ]; then
	rm ${launch_path_new} 2> /dev/null

	IFS=$'\n'
	for line in $(cat ${launch_path}); do
		if [[ ${line} == *"# ${core^} External"* ]] || [[ ${line} == *"\"\$CORE\" = ext-${core} ];"* ]]; then
			removing=true
		elif [[ ${line} == elif* ]] || [[ ${line} == fi* ]] || [[ ${line} == \#* ]]; then
			removing=false
		fi

		if [ "${removing}" != "true" ]; then
		  echo ${line} >> ${launch_path_new}
		fi
	done

	mv ${launch_path_new} ${launch_path}
	chmod +x ${launch_path}
fi

