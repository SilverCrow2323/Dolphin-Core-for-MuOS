#!/bin/bash

# Adds all dolphin options as cores to launch.sh

script_file=$(readlink -f ${0})
script_dir=${script_file%/*}

cores_single=(dolphin)
cores_many_hasjoys=(
	dolphin-defaultgfx-hasjoys-upright
	dolphin-defaultgfx-hasjoys-sideways
	dolphin-speedhack-hasjoys-upright
	dolphin-speedhack-hasjoys-sideways
	dolphin-blackscreenfix-hasjoys-upright
	dolphin-blackscreenfix-hasjoys-sideways
)
cores_many_nojoys=(
	dolphin-defaultgfx-nojoys-upright
	dolphin-defaultgfx-nojoys-sideways
	dolphin-speedhack-nojoys-upright
	dolphin-speedhack-nojoys-sideways
	dolphin-blackscreenfix-nojoys-upright
	dolphin-blackscreenfix-nojoys-sideways
)

cd ${script_dir}
for file in $(ls -1); do
	if [[ ${file} == add-ext-core-* ]]; then
		add_core_src_file=${file}
	fi
done


for file in $(ls -1); do
	if [[ ${file} == remove-ext-core-* ]]; then
		remove_core_src_file=${file}
	fi
done

if [ ${add_core_src_file} != "" ] && [ ${remove_core_src_file} != "" ]; then
	chmod +x ${add_core_src_file}
	chmod +x ${remove_core_src_file}
	
	cores_to_remove=( "${cores_single[@]}" "${cores_many_hasjoys[@]}" "${cores_many_nojoys[@]}" )
	for core_to_remove in ${cores_to_remove[@]}; do
		./${remove_core_src_file} ${core_to_remove}
	done

	cores_to_add=( "${cores_many_hasjoys[@]}" "${cores_many_nojoys[@]}" )
	for core_to_add in ${cores_to_add[@]}; do
		./${add_core_src_file} ${core_to_add} /opt/muos/script/launch/ext-dolphin.sh
	done

	rm ${add_core_src_file}
	rm ${remove_core_src_file}
fi
